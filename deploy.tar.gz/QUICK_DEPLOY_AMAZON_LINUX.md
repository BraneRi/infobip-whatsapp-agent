# Quick Deploy to Amazon Linux 2023

Your EC2 instance: `ip-172-31-42-80.eu-central-1.compute.internal` (ARM64)

## Option 1: Automated Deployment Script

```bash
./deploy-ec2-amazon-linux.sh ec2-user@ip-172-31-42-80.eu-central-1.compute.internal path/to/your-key.pem
```

## Option 2: Manual Deployment

### Step 1: SSH into your instance
```bash
ssh -i your-key.pem ec2-user@ip-172-31-42-80.eu-central-1.compute.internal
```

### Step 2: Install Node.js 18.x (ARM64)
```bash
# Update system
sudo dnf update -y

# Install Node.js 18.x
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo dnf install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 3: Install PM2
```bash
sudo npm install -g pm2
```

### Step 4: Clone or upload your code
```bash
# Option A: If you have git repo
git clone your-repo-url
cd ib-whatsapp-demo

# Option B: Upload files manually
# Use scp from your local machine:
# scp -i your-key.pem -r . ec2-user@ip-172-31-42-80.eu-central-1.compute.internal:~/whatsapp-bot
```

### Step 5: Install dependencies
```bash
cd ~/whatsapp-bot
npm install --production
```

### Step 6: Create .env file
```bash
nano .env
```

Add your environment variables:
```env
INFOBIP_API_KEY=your_key_here
OPENAI_API_KEY=your_key_here
WHATSAPP_SENDER=385916376631
OPENAI_MODEL=gpt-4o-mini
PORT=3000
NODE_ENV=production
```

Save and exit (Ctrl+X, then Y, then Enter)

### Step 7: Start with PM2
```bash
pm2 start server.js --name whatsapp-bot
pm2 save
pm2 startup
```

Follow the command it outputs to enable PM2 on system startup.

### Step 8: Check status
```bash
pm2 status
pm2 logs whatsapp-bot
```

### Step 9: Set up Nginx (for HTTPS and reverse proxy)

```bash
# Install Nginx
sudo dnf install -y nginx

# Create Nginx config
sudo nano /etc/nginx/conf.d/whatsapp-bot.conf
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;  # Or use your EC2 public IP

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable and start Nginx:
```bash
sudo systemctl enable nginx
sudo systemctl start nginx
sudo nginx -t  # Test configuration
sudo systemctl reload nginx
```

### Step 10: Configure Security Group

In AWS Console:
1. Go to EC2 → Security Groups
2. Find your instance's security group
3. Add inbound rule:
   - Type: HTTP
   - Port: 80
   - Source: 0.0.0.0/0 (or restrict to specific IPs)

### Step 11: Get your public IP

```bash
curl http://169.254.169.254/latest/meta-data/public-ipv4
```

Or check in AWS Console: EC2 → Instances → Your instance

### Step 12: Configure Infobip Webhook

Use your EC2 public IP or domain:
```
http://your-ec2-public-ip/
```

Or if you set up a domain:
```
http://your-domain.com/
```

## Useful Commands

```bash
# View logs
pm2 logs whatsapp-bot

# Restart app
pm2 restart whatsapp-bot

# Stop app
pm2 stop whatsapp-bot

# View PM2 status
pm2 status

# Monitor resources
pm2 monit

# Check Nginx status
sudo systemctl status nginx

# View Nginx logs
sudo tail -f /var/log/nginx/error.log
```

## Troubleshooting

### Check if app is running
```bash
curl http://localhost:3000/health
```

### Check if port is accessible
```bash
sudo netstat -tlnp | grep 3000
```

### View application logs
```bash
pm2 logs whatsapp-bot --lines 100
```

### Check system resources
```bash
free -h
df -h
top
```

