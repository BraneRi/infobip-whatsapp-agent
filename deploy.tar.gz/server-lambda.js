// Lambda handler wrapper for serverless deployment
const serverless = require('serverless-http');
const app = require('./server');

// Export the handler
module.exports.handler = serverless(app);

