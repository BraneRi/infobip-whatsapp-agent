# AWS Deployment Guide

This guide covers deploying the WhatsApp bot to AWS using different methods.

## Option 1: AWS Elastic Beanstalk (Easiest)

### Prerequisites
- AWS CLI installed and configured
- EB CLI installed: `pip install awsebcli`

### Steps

1. **Initialize Elastic Beanstalk:**
   ```bash
   eb init -p node.js whatsapp-bot --region us-east-1
   ```

2. **Create environment:**
   ```bash
   eb create whatsapp-bot-env
   ```

3. **Set environment variables:**
   ```bash
   eb setenv \
     INFOBIP_API_KEY=your_key \
     OPENAI_API_KEY=your_key \
     WHATSAPP_SENDER=385916376631 \
     OPENAI_MODEL=gpt-4o-mini \
     NODE_ENV=production \
     PORT=8080
   ```

4. **Deploy:**
   ```bash
   eb deploy
   ```

5. **Get your URL:**
   ```bash
   eb status
   ```
   Use the CNAME as your webhook URL in Infobip.

## Option 2: AWS EC2 (More Control)

### Prerequisites
- EC2 instance running (Ubuntu/Amazon Linux)
- PEM file for SSH access
- Security group allowing HTTP/HTTPS traffic

### Deployment Script

Use the provided `deploy-ec2.sh` script (see below) or follow manual steps:

1. **SSH into your EC2 instance:**
   ```bash
   ssh -i your-key.pem ubuntu@your-ec2-ip
   ```

2. **Install Node.js:**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **Install PM2 (process manager):**
   ```bash
   sudo npm install -g pm2
   ```

4. **Clone your repository:**
   ```bash
   git clone your-repo-url
   cd ib-whatsapp-demo
   ```

5. **Create .env file:**
   ```bash
   nano .env
   # Add your environment variables
   ```

6. **Install dependencies and start:**
   ```bash
   npm install
   pm2 start server.js --name whatsapp-bot
   pm2 save
   pm2 startup
   ```

7. **Set up Nginx reverse proxy:**
   ```bash
   sudo apt-get install nginx
   sudo nano /etc/nginx/sites-available/whatsapp-bot
   ```

   Add this configuration:
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;

       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

   Enable and restart:
   ```bash
   sudo ln -s /etc/nginx/sites-available/whatsapp-bot /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

## Option 3: AWS ECS with Docker

### Create Dockerfile

The `Dockerfile` is already created (see below).

### Steps

1. **Build and push Docker image:**
   ```bash
   docker build -t whatsapp-bot .
   docker tag whatsapp-bot:latest your-account.dkr.ecr.region.amazonaws.com/whatsapp-bot:latest
   docker push your-account.dkr.ecr.region.amazonaws.com/whatsapp-bot:latest
   ```

2. **Create ECS task definition** with environment variables

3. **Create ECS service** and configure load balancer

4. **Use load balancer URL** as webhook in Infobip

## Option 4: AWS Lambda + API Gateway

### Prerequisites
- Serverless Framework: `npm install -g serverless`

### Steps

1. **Install serverless plugins:**
   ```bash
   npm install --save-dev serverless-offline
   ```

2. **Create `serverless.yml`** (see below)

3. **Deploy:**
   ```bash
   serverless deploy
   ```

## Environment Variables

All methods require these environment variables:
- `INFOBIP_API_KEY`
- `OPENAI_API_KEY`
- `WHATSAPP_SENDER`
- `OPENAI_MODEL` (optional, defaults to gpt-4)
- `PORT` (optional, defaults to 3000)
- `NODE_ENV=production`

## Security Considerations

1. **Never commit .env files**
2. **Use AWS Secrets Manager** for production
3. **Enable HTTPS** (use AWS Certificate Manager)
4. **Set up CloudWatch** for logging
5. **Configure security groups** properly
6. **Use IAM roles** instead of access keys when possible

## Monitoring

- **CloudWatch Logs**: View application logs
- **CloudWatch Metrics**: Monitor performance
- **Set up alarms** for errors and high latency

## Troubleshooting

### Check logs:
```bash
# Elastic Beanstalk
eb logs

# EC2 with PM2
pm2 logs whatsapp-bot

# ECS
aws logs tail /ecs/whatsapp-bot --follow
```

### Health check:
```bash
curl https://your-domain.com/health
```

