#!/bin/bash

# AWS EC2 Deployment Script for Amazon Linux 2023
# Usage: ./deploy-ec2-amazon-linux.sh [ec2-user@your-instance-ip] [path-to-pem-file]

set -e

EC2_HOST=${1:-"ec2-user@your-ec2-ip"}
PEM_FILE=${2:-"~/.ssh/your-key.pem"}

echo "🚀 Deploying WhatsApp Bot to Amazon Linux 2023 EC2..."
echo "   Host: $EC2_HOST"
echo "   PEM: $PEM_FILE"
echo ""

# Check if PEM file exists
if [ ! -f "$PEM_FILE" ]; then
    echo "❌ PEM file not found: $PEM_FILE"
    echo "   Usage: ./deploy-ec2-amazon-linux.sh ec2-user@your-ip path/to/key.pem"
    exit 1
fi

# Create deployment package
echo "📦 Creating deployment package..."
tar --exclude='node_modules' \
    --exclude='.git' \
    --exclude='.env' \
    --exclude='*.log' \
    --exclude='.DS_Store' \
    -czf deploy.tar.gz .

# Copy to EC2
echo "📤 Copying files to EC2..."
scp -i "$PEM_FILE" deploy.tar.gz "$EC2_HOST:/tmp/"

# SSH and deploy
echo "🔧 Setting up on Amazon Linux 2023..."
ssh -i "$PEM_FILE" "$EC2_HOST" << 'ENDSSH'
    set -e
    
    # Create app directory
    mkdir -p ~/whatsapp-bot
    cd ~/whatsapp-bot
    
    # Extract files
    tar -xzf /tmp/deploy.tar.gz
    rm /tmp/deploy.tar.gz
    
    # Update system packages
    echo "📦 Updating system packages..."
    sudo dnf update -y
    
    # Install Node.js if not present (for ARM64)
    if ! command -v node &> /dev/null; then
        echo "📦 Installing Node.js 18.x for ARM64..."
        # For Amazon Linux 2023, use NodeSource or install from dnf
        curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
        sudo dnf install -y nodejs
    fi
    
    # Verify Node.js version
    echo "✅ Node.js version: $(node --version)"
    echo "✅ npm version: $(npm --version)"
    
    # Install PM2 if not present
    if ! command -v pm2 &> /dev/null; then
        echo "📦 Installing PM2..."
        sudo npm install -g pm2
    fi
    
    # Install dependencies
    echo "📦 Installing dependencies..."
    npm install --production
    
    # Check if .env exists
    if [ ! -f .env ]; then
        echo "⚠️  .env file not found!"
        echo ""
        echo "📝 Creating .env template..."
        cat > .env << 'ENVFILE'
# Infobip Configuration
INFOBIP_API_KEY=your_infobip_api_key_here
INFOBIP_BASE_URL=https://api.infobip.com
WHATSAPP_SENDER=385916376631

# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_MODEL=gpt-4o-mini

# Server Configuration
PORT=3000
NODE_ENV=production
ENVFILE
        echo "✅ Created .env file template"
        echo ""
        echo "⚠️  IMPORTANT: Edit .env file and add your API keys:"
        echo "   nano .env"
        echo ""
        read -p "Press Enter after you've updated .env file..."
    fi
    
    # Set proper permissions
    chmod 600 .env
    
    # Stop existing instance if running
    echo "🔄 Stopping existing instance (if any)..."
    pm2 delete whatsapp-bot 2>/dev/null || true
    
    # Start with PM2
    echo "🚀 Starting application with PM2..."
    pm2 start server.js --name whatsapp-bot
    pm2 save
    
    # Setup PM2 startup script
    echo "⚙️  Setting up PM2 startup..."
    pm2 startup systemd -u $USER --hp $HOME | grep -v PM2 | sudo bash || true
    
    # Show status
    echo ""
    echo "✅ Deployment complete!"
    echo ""
    pm2 status
    echo ""
    echo "📝 Useful commands:"
    echo "   View logs: pm2 logs whatsapp-bot"
    echo "   Restart: pm2 restart whatsapp-bot"
    echo "   Stop: pm2 stop whatsapp-bot"
    echo "   Status: pm2 status"
ENDSSH

# Cleanup
rm -f deploy.tar.gz

echo ""
echo "✅ Deployment successful!"
echo ""
echo "📝 Next steps:"
echo "   1. SSH into server: ssh -i $PEM_FILE $EC2_HOST"
echo "   2. Edit .env file: nano ~/whatsapp-bot/.env"
echo "   3. Restart app: pm2 restart whatsapp-bot"
echo "   4. Check logs: pm2 logs whatsapp-bot"
echo "   5. Set up Nginx reverse proxy (see AWS_DEPLOYMENT.md)"
echo "   6. Configure webhook URL in Infobip"

