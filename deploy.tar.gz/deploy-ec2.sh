#!/bin/bash

# AWS EC2 Deployment Script
# Usage: ./deploy-ec2.sh [ec2-user@your-instance-ip] [path-to-pem-file]

set -e

EC2_HOST=${1:-"ubuntu@your-ec2-ip"}
PEM_FILE=${2:-"~/.ssh/your-key.pem"}

echo "🚀 Deploying WhatsApp Bot to EC2..."
echo "   Host: $EC2_HOST"
echo "   PEM: $PEM_FILE"
echo ""

# Check if PEM file exists
if [ ! -f "$PEM_FILE" ]; then
    echo "❌ PEM file not found: $PEM_FILE"
    echo "   Usage: ./deploy-ec2.sh ec2-user@your-ip path/to/key.pem"
    exit 1
fi

# Create deployment package
echo "📦 Creating deployment package..."
tar --exclude='node_modules' \
    --exclude='.git' \
    --exclude='.env' \
    --exclude='*.log' \
    -czf deploy.tar.gz .

# Copy to EC2
echo "📤 Copying files to EC2..."
scp -i "$PEM_FILE" deploy.tar.gz "$EC2_HOST:/tmp/"

# SSH and deploy
echo "🔧 Setting up on EC2..."
ssh -i "$PEM_FILE" "$EC2_HOST" << 'ENDSSH'
    set -e
    
    # Create app directory
    mkdir -p ~/whatsapp-bot
    cd ~/whatsapp-bot
    
    # Extract files
    tar -xzf /tmp/deploy.tar.gz
    
    # Install Node.js if not present
    if ! command -v node &> /dev/null; then
        echo "📦 Installing Node.js..."
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
    
    # Install PM2 if not present
    if ! command -v pm2 &> /dev/null; then
        echo "📦 Installing PM2..."
        sudo npm install -g pm2
    fi
    
    # Install dependencies
    echo "📦 Installing dependencies..."
    npm install --production
    
    # Check if .env exists
    if [ ! -f .env ]; then
        echo "⚠️  .env file not found!"
        echo "   Please create .env file with required variables:"
        echo "   INFOBIP_API_KEY=..."
        echo "   OPENAI_API_KEY=..."
        echo "   WHATSAPP_SENDER=..."
        echo "   OPENAI_MODEL=gpt-4o-mini"
        echo "   NODE_ENV=production"
        echo "   PORT=3000"
        exit 1
    fi
    
    # Restart with PM2
    echo "🔄 Restarting application..."
    pm2 delete whatsapp-bot 2>/dev/null || true
    pm2 start server.js --name whatsapp-bot
    pm2 save
    
    # Setup PM2 startup
    pm2 startup | grep -v PM2 | bash || true
    
    echo "✅ Deployment complete!"
    echo "   Check status: pm2 status"
    echo "   View logs: pm2 logs whatsapp-bot"
ENDSSH

# Cleanup
rm -f deploy.tar.gz

echo ""
echo "✅ Deployment successful!"
echo ""
echo "📝 Next steps:"
echo "   1. SSH into server: ssh -i $PEM_FILE $EC2_HOST"
echo "   2. Check status: pm2 status"
echo "   3. View logs: pm2 logs whatsapp-bot"
echo "   4. Set up Nginx reverse proxy (see AWS_DEPLOYMENT.md)"
echo "   5. Configure webhook URL in Infobip"

